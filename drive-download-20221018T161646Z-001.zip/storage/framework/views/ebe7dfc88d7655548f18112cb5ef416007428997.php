

<?php $__env->startSection('content'); ?>

<div class="hero-wrap hero-bread" style="background-image: url(<?php echo e(asset('home-asset/images/bg_1.jpg')); ?>);">
  <div class="container-fluid" style="background-color: rgba(0, 0, 0, 0.2); padding: 15em 0;">
    <div class="row no-gutters slider-text align-items-center justify-content-center">
      <div class="col-md-10 ftco-animate text-center">
        <p class="breadcrumbs"><span class="mr-2"><a href="<?php echo e(route('home')); ?>">Home</a></span> <span>Products</span>
        </p>
        <h1 class="mb-0 display-3 text-light">Products</h1>
      </div>
    </div>
  </div>
</div>

<section class="ftco-section">
  <div class="container">
    <div class="row">
      <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <div class="col-md-6 col-lg-3 ftco-animate">
        <div class="product">
          <?php if($product->image): ?>
          <a href="<?php echo e(route('product.show', $product)); ?>" class="img-prod"><img class="img-fluid"
              src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>">
            <div class="overlay"></div>
          </a>
          <?php else: ?>
          <a href="<?php echo e(route('product.show', $product)); ?>" class="img-prod"><img class="img-fluid"
              src="<?php echo e(asset('storage/product-image/product-default.jpg')); ?>" alt="<?php echo e($product->name); ?>">
            <div class="overlay"></div>
          </a>
          <?php endif; ?>
          <div class="text py-3 pb-4 px-3 text-center">
            <h3><a href="#"><?php echo e($product->name); ?></a></h3>
            <div class="d-flex">
              <div class="pricing">
                <p class="price">
                  <span class="price-sale">Rp
                    <?php echo e(number_format($product->price, 0, ',', '.')); ?></span>
                </p>
              </div>
            </div>
            <?php if(!$cart->where('id', $product->id)->count()): ?>
            <div class="bottom-area d-flex px-3">
              <div class="m-auto d-flex">
                <form action="<?php echo e(route('cart.store')); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="quantity" value="1">
                  <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">

                  <button type="submit" class="buy-now d-flex justify-content-center align-items-center mx-1 ">
                    <span><i class="ion-ios-cart"></i> Add To Cart</span>
                  </button>
                </form>
              </div>
            </div>
            <?php endif; ?>
          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <h2>Empty</h2>
      <?php endif; ?>
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Sains Data\Semester 4\sertifikasi\sertifikasi_grandonk\sehat-sentosa\resources\views/product/index.blade.php ENDPATH**/ ?>