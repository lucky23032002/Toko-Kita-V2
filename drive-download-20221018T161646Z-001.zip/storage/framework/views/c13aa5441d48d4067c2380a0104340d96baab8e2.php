

<?php $__env->startSection('content'); ?>

<div class="container-fluid p-0">
  <h1 class="display-6 mb-3"><?php echo e($title); ?></h1>

  <div class="row">
    <div class="col-12 col-lg-12">

      <div class="row justify-content-between d-print-none">
        <div class="col-md-3">
          <a href="#" onclick="window.print()" class="btn btn-success mb-3 d-block"><i
              data-feather="printer"></i>Print</a>
        </div>
      </div>

      <?php if(session()->has('success')): ?>
      <div class="alert alert-success alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <div class="alert-message">
          <?php echo e(session('success')); ?>

        </div>
      </div>
      <?php endif; ?>


      <div class="card rounded-3 overflow-hidden">
        <table class="table">
          <thead class="table-dark">
            <tr>
              <th>Customer
              </th>
              <th>Total Item</th>
              <th>Type
              </th>
              <th>Total</th>
              <th class="d-print-none d-none d-xl-table-cell">Action
              </th>
            </tr>
          </thead>
          <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
              <td>
                <?php echo e($transaction->user->firstname); ?></td>
              <td><?php echo e($transaction->orders->count()); ?></td>
              <td>
                <?php echo e($transaction->payment_type); ?></td>
              <td>Rp <?php echo e(number_format($transaction->total, '0', '', '.')); ?>

              </td>
              <td class="d-print-none d-none d-xl-table-cell">
                <a href="<?php echo e(route('admin.transaction.show', $transaction)); ?>" class="btn btn-info">Detail</a>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
              <td>
                No Transaction Yet
              </td>
            </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Grandonk\sertifikasi_grandonk\sehat-sentosa\resources\views/admin/transaction/index.blade.php ENDPATH**/ ?>