

<?php $__env->startSection('content'); ?>

  <div class="container-fluid p-0">

    <h1 class="display-6 mb-3"><?php echo e($title); ?></h1>

    <div class="row">
      <div class="col-12">
        <div class="card">
          <div class="card-body">

            <form action="<?php echo e(route('admin.product.update', $product)); ?>"
              method="post" enctype="multipart/form-data">
              <?php echo method_field('PUT'); ?>
              <?php echo csrf_field(); ?>

              <div class="form-group row mb-3">
                <label for="name" class="col-form-label col-sm-2">Name</label>
                <div class="col-sm-10">
                  <input type="text"
                    class="slug-from form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    id="name" name="name"
                    value="<?php echo e(old('name', $product->name)); ?>">
                  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>

              <div class="form-group row mb-3">
                <label for="slug" class="col-form-label col-sm-2">Slug</label>
                <div class="col-sm-10">
                  <input type="text" readonly
                    class="slug-field form-control <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    id="slug" name="slug"
                    value="<?php echo e(old('slug', $product->slug)); ?>">
                  <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>

              <div class="form-group row mb-3">
                <label for="category_id"
                  class="col-form-label col-sm-2">Category</label>
                <div class="col-sm-10">
                  <select name="category_id"
                    class="form-select <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <option value=""> -- Select Category -- </option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if(old('category_id', $product->category_id) == $category->id): ?>
                        <option selected value="<?php echo e($category->id); ?>">
                          <?php echo e($category->name); ?>

                        </option>
                      <?php else: ?>
                        <option value="<?php echo e($category->id); ?>">
                          <?php echo e($category->name); ?>

                        </option>
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>

              <div class="form-group row mb-3">
                <label for="price" class="col-form-label col-sm-2">Price</label>
                <div class="col-sm-10">
                  <input type="number"
                    class="slug-from form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    id="price" name="price"
                    value="<?php echo e(old('price', $product->price)); ?>">
                  <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>

              <div class="form-group row mb-3">
                <?php if($product->image): ?>
                  <div class="img-container d-flex justify-content-end">
                    <img height="120" width="120"
                      src="<?php echo e(asset('storage/' . $product->image)); ?>"
                      class="img-preview mb-2 border border-dark"
                      style="object-fit: cover;">
                  </div>
                <?php else: ?>
                  <div class="d-none img-container justify-content-end">
                    <img height="120" width="120"
                      class="img-preview mb-2 border border-dark"
                      style="object-fit: cover;">
                  </div>
                <?php endif; ?>

                <label for="image" class="col-form-label col-sm-2">Image</label>
                <input type="hidden" name="oldImage"
                  value="<?php echo e($product->sampul); ?>">

                <div class="col-sm-10">
                  <input onchange="previewImg();" name="image"
                    class="img-input form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    type="file">
                  <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>

              <div class="form-group row mb-3">
                <label for="detail" class="col-form-label col-sm-2">Detail</label>
                <div class="col-sm-10">
                  <textarea name="detail"
                    class="form-control <?php $__errorArgs = ['detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    id="detail"
                    rows="4"><?php echo e(old('detail', $product->detail)); ?></textarea>
                  <?php $__errorArgs = ['detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>

              

              <div class="d-flex justify-content-end">
                <button type="submit" class="btn btn-primary mr-2">
                  Submit
                </button>
                <a class="btn btn-warning"
                  href="<?php echo e(route('admin.product.index')); ?>">
                  Cancel
                </a>
              </div>

            </form>

          </div>
        </div>
        <form action="<?php echo e(route('admin.product.destroy', $product)); ?>"
          method="POST">
          <?php echo method_field('DELETE'); ?>
          <?php echo csrf_field(); ?>

          <button onclick="return confirm('Are You Sure ?')" type="submit"
            class="btn btn-lg btn-danger rounded mb-3">Delete
            Product</button>
        </form>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
  <script src="<?php echo e(asset('admin-asset/js/imagePreview.js')); ?>"></script>
  <script src="<?php echo e(asset('admin-asset/js/generateSlug.js')); ?>"></script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Grandonk\sertifikasi_grandonk\sehat-sentosa\resources\views/admin/product/edit.blade.php ENDPATH**/ ?>