

<?php $__env->startSection('content'); ?>

<div class="container-fluid p-0">
  <h1 class="display-6 mb-3"><?php echo e($title); ?></h1>

  <?php if(auth()->user()->is_admin): ?>
  <div class="row justify-content-between d-print-none">
    <div class="col-md-6">
      <form action="<?php echo e(route('admin.transaction.reciept', $transaction)); ?>" method="POST">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>

        <div class="input-group mb-3">
          <input type="text" class="form-control py-2" placeholder="Reciept Number" name="reciept_number"
            value="<?php echo e(old('reciept_number', $transaction->reciept_number)); ?>">
          <button class="btn btn-info" type="submit">
            <?php if($transaction->reciept_number): ?>
            Update Reciept Number
            <?php else: ?>
            Set Reciept Number
            <?php endif; ?>
          </button>
        </div>
      </form>
    </div>
  </div>
  <?php endif; ?>

  <div class="row">
    <div class="col-md-6">
      <div class="card">
        <ul class="list-group list-group-flush">
          <li class="d-flex list-group-item py-3 justify-content-between">
            <strong>Serial Order</strong>
            <span><?php echo e($transaction->serial_order); ?></span>
          </li>
          <li class="d-flex list-group-item py-3 justify-content-between">
            <strong>Customer Name</strong>
            <span><?php echo e($transaction->user->firstname); ?>

              <?php echo e($transaction->user->lastname); ?></span>
          </li>
          <li class="d-flex list-group-item py-3 justify-content-between">
            <strong>Total Item</strong>
            <span><?php echo e($transaction->orders->count()); ?></span>
          </li>
          <li class="d-flex list-group-item py-3 justify-content-between">
            <strong>Total</strong>
            <span>Rp
              <?php echo e(number_format($transaction->total, '0', '', '.')); ?></span>
          </li>
          <li class="d-flex list-group-item py-3 justify-content-between">
            <strong>Payment Type</strong>
            <span><?php echo e($transaction->payment_type); ?></span>
          </li>
          <li class="d-flex list-group-item py-3 justify-content-between">
            <strong>Payment Code / VA Number</strong>
            <span><?php echo e($transaction->payment_code); ?></span>
          </li>
          <li class="d-flex list-group-item py-3 justify-content-between">
            <strong>Status</strong>
            <p class="m-0"><span class="badge bg-<?php echo e($detail['badge']); ?> text-light text-uppercase">
                <?php echo e($transaction->status); ?>

              </span></p>
          </li>
          <?php if($transaction->reciept_number): ?>
          <li class="d-flex list-group-item py-3 justify-content-between">
            <strong>Reciept Number</strong>
            <span><?php echo e($transaction->reciept_number); ?></span>
          </li>
          <?php endif; ?>
        </ul>
      </div>
    </div>

    <?php if($detail['pesan'] != ''): ?>
    <div class="col-md-6">
      <div class="card">
        <div class="card-body">
          <div class="card-text">
            <p class="h4 mb-2"><?php echo e($detail['pesan']); ?></p>
            <?php if($transaction->reciept_number): ?>
            <p class="h4 text-muted mb-2">This is the reciept number</p>
            <p class="h4 text-muted mb-2"><?php echo e($transaction->reciept_number); ?></p>
            <?php endif; ?>
            <?php if($detail['pdf'] != ''): ?>
            <p class="h4 text-muted mb-2">You can get step by step payment here</p>
            <a class="btn btn-primary mb-2" href="<?php echo e($detail['pdf']); ?>" target="_blank">Download Instructions</a>
            <?php endif; ?>
            <?php if($detail['bill'] != ''): ?>
            <p class="h4 text-muted mb-2">atau Anda bisa mendapatkan nota
              bukti pembayaran melalui tombol dibawah</p>
            <a class="btn btn-primary mb-2" href="#">Download Nota</a>
            <?php endif; ?>
          </div>
        </div>
      </div>
      <div class="card">
        <div class="py-3">
          <div class="card-header my-0 py-0">
            <h4>List Item</h4>
          </div>
          <div class="card-body my-0 py-0">
            <ul class="list-group list-group-flush my-0 py-0">
              <?php $__currentLoopData = $transaction->orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li class="d-flex list-group-item justify-content-between py-1">
                <span><?php echo e($order->product->name); ?> x <?php echo e($order->quantity); ?></span>
                <span>Rp <?php echo e(number_format($order->quantity * $order->product->price, '0', '', '.')); ?></span>
              </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
        </div>
        <div class="py-3">
          <div class="card-header my-0 py-0">
            <h4>Delivery</h4>
          </div>
          <div class="card-body my-0 py-0">
            <ul class="list-group list-group-flush my-0 py-0">
              <li class="d-flex list-group-item justify-content-between my-0 py-0">
                <span><?php echo e($transaction->delivery_service); ?></span>
                <span>Rp <?php echo e(number_format($transaction->delivery_cost, '0', '', '.')); ?></span>
              </li>
            </ul>
          </div>
        </div>
        <div class="py-3">
          <div class="card-header my-0 py-0 d-flex justify-content-between">
            <h4>Total</h4>
            <span class="px-4">Rp <?php echo e(number_format($transaction->total, '0', '', '.')); ?></span>
          </div>
        </div>
      </div>
    </div>
    <?php endif; ?>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Grandonk\sertifikasi_grandonk\sehat-sentosa\resources\views/admin/transaction/show.blade.php ENDPATH**/ ?>