

<?php $__env->startSection('content'); ?>

  <div class="container-fluid p-0">
    <h1 class="display-6 mb-3"><?php echo e($title); ?></h1>

    <div class="row">
      <div class="col-12 col-lg-12 col-xxl-9">

        <div class="col-sm-3">
          <a href="<?php echo e(route('admin.category.create')); ?>"
            class="btn btn-primary mb-3 d-block d-print-none"><i
              data-feather="plus"></i>Add Category</a>
        </div>

        <?php if(session()->has('success')): ?>
          <div class="alert alert-success alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert"
              aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
            <div class="alert-message">
              <?php echo e(session('success')); ?>

            </div>
          </div>
        <?php endif; ?>

        <div class="card rounded-3 overflow-hidden">
          <table class="table table-hover">
            <thead class="table-dark">
              <tr>
                <th>Name</th>
                <th>Total Products</th>
              </tr>
            </thead>
            <tbody>
              <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr
                  onclick="window.location.href = '<?php echo e(route('admin.category.edit', $category)); ?>'"
                  style="cursor: pointer;">
                  <td><?php echo e($category->name); ?></td>
                  <td>
                    <?php echo e(count($category->products)); ?>

                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <h2>Empty</h2>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Grandonk\sertifikasi_grandonk\sehat-sentosa\resources\views/admin/category/index.blade.php ENDPATH**/ ?>