

<?php $__env->startSection('content'); ?>

<div class="hero-wrap hero-bread" style="background-image: url(<?php echo e(asset('home-asset/images/bg_2.jpg')); ?>);">
  <div class="container-fluid" style="background-color: rgba(0, 0, 0, 0.2); padding: 15em 0;">
    <div class="row no-gutters slider-text align-items-center justify-content-center">
      <div class="col-md-10 ftco-animate text-center">
        <p class="breadcrumbs"><span class="mr-2"><a href="<?php echo e(route('home')); ?>">Home</a></span> <span>Checkout</span>
        </p>
        <h1 class="mb-0 display-3 text-light">Checkout</h1>
      </div>
    </div>
  </div>
</div>

<section class="ftco-section">
  <div class="container">
    <div class="row justify-content-center">

      <div class="col-xl-7 ftco-animate">
        <h3 class="mb-4 billing-heading">Your Billing Information</h3>

        <div class="row align-items-end">
          <div class="col-md-6">
            <div class="form-group">
              <label for="firstname">First Name</label>
              <input type="text" name="firstname" required class="form-control" style="color:black !important"
                placeholder="" id="firstname" value="<?php echo e(auth()->user()->firstname); ?>" disabled>
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label for="lastname">Last Name</label>
              <input type="text" name="lastname" required class="form-control" style="color:black !important"
                placeholder="" id="lastname" value="<?php echo e(auth()->user()->lastname); ?>" disabled>
            </div>
          </div>
          <div class="w-100"></div>
          <div class="col-md-12">
            <div class="form-group">
              <label for="email">Email</label>
              <input type="text" name="email" required class="form-control" style="color:black !important"
                placeholder="" id="email" value="<?php echo e(auth()->user()->email); ?>" disabled>
            </div>
          </div>
          <div class="w-100"></div>
          <div class="col-md-12">
            <div class="form-group">
              <label for="address">Detail Address</label>
              <input type="text" name="address" required class="form-control" style="color:black !important"
                placeholder="" id="address" value="<?php echo e(auth()->user()->address); ?>" disabled>
            </div>
          </div>
          <div class="w-100"></div>
          <div class="col-md-6">
            <div class="form-group">
              <label for="province">Province</label>
              <input type="text" name="province" required class="form-control" style="color:black !important"
                placeholder="" id="province" value="<?php echo e(auth()->user()->province); ?>" disabled>
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label for="city">City</label>
              <input type="text" name="city" required class="form-control" style="color:black !important" placeholder=""
                id="city" value="<?php echo e(auth()->user()->city); ?>" disabled>
            </div>
          </div>
          <div class="w-100"></div>
          <div class="col-md-6">
            <div class="form-group">
              <label for="postal_code">Postal Code</label>
              <input type="text" name="postal_code" required class="form-control" style="color:black !important"
                placeholder="" id="postal_code" value="<?php echo e(auth()->user()->postal_code); ?>" disabled>
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label for="phone">Phone Number</label>
              <input type="text" name="phone" required class="form-control" style="color:black !important"
                placeholder="" id="phone" value="<?php echo e(auth()->user()->phone); ?>" disabled>
            </div>
          </div>
        </div>
      </div>

      <div class="col-xl-5">
        <div class="row mt-5 pt-3">

          <div class="col-md-12">
            <div class="form-group" id="delivery-section">
              <label for="delivery">Delivery Option</label>
              <select name="delivery" id="delivery" required
                class="form-control <?php $__errorArgs = ['delivery-cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" style="color:black !important">
                <option value=""> -- Select Delivery Option -- </option>
                <?php $__currentLoopData = $listCost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($cost['cost'][0]['value']); ?>__<?php echo e($cost['service']); ?>">
                  JNE <?php echo e($cost['service']); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              <?php $__errorArgs = ['delivery-cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback">
                <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>

          <div class="col-md-12 d-flex mb-3">
            <div class="cart-detail cart-total p-3 p-md-4">
              <h3 class="billing-heading mb-4">Cart Total</h3>

              <div id="checkout-detail">
                <p class="d-flex">
                  <span>Subtotal</span>
                  <span><?php echo e($subtotal); ?></span>
                </p>
              </div>
              <hr>
              <p class="d-flex total-price">
                <span>Total</span>
                <span class="total"><?php echo e($total); ?></span>
              </p>

              <button class="btn btn-primary py-3 px-4" id="pay-btn" type="button">
                
                Place Order
              </button>
            </div>
          </div>
        </div>
      </div> <!-- .col-md-8 -->

    </div>

  </div>

  </div>
</section> <!-- .section -->

<form id="finish-form" action="<?php echo e(route('admin.checkout.finish')); ?>" method="post" style="display: hidden;">
  <?php echo csrf_field(); ?>

  <input type="hidden" name="result-data">
  <input type="hidden" name="delivery-cost">
  <input type="hidden" name="delivery-service">
</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script src="https://app.sandbox.midtrans.com/snap/snap.js" data-client-key="SB-Mid-client-ZK2Q4mMwnOvnPZFO"></script>

<script>
  $(document).ready(function() {
      $('#pay-btn').click(function(e) {
        e.preventDefault();

        let deliveryCost = $('input[name="delivery-cost"]').val()
        let deliveryService = $('input[name="delivery-service"]').val()

        if (!deliveryCost) {
          $('select[name="delivery"]').addClass('is-invalid')
          $('#delivery-section').append(
            `<div class="invalid-feedback">
              Select an option
            </div>`
          )
          return
        }

        $('#pay-btn').prop('disabled', true);
        $('#pay-btn').html(
          `<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
          Processing`
        )

        $.ajax({
          url: `/admin/checkout/token?delivery_cost=${deliveryCost}&delivery_service=${deliveryService}`,
          type: "GET",
          dataType: "json",
          success: function(response) {
            console.log(response)
            snap.pay(response.token, {
              onSuccess: function(result) {
                $('input[name="result-data"]').val(JSON
                  .stringify(result, null, 2))
                $('input[name="delivery-cost"]').val(deliveryCost)
                $('input[name="delivery-service"]').val(deliveryService)
                $('#finish-form').submit()
              },
              onPending: function(result) {
                $('input[name="result-data"]').val(JSON
                  .stringify(result, null, 2))
                $('input[name="delivery-cost"]').val(deliveryCost)
                $('input[name="delivery-service"]').val(deliveryService)
                $('#finish-form').submit()
              },
              onError: function(result) {
                $('input[name="result-data"]').val(JSON
                  .stringify(result, null, 2))
                $('input[name="delivery-cost"]').val(deliveryCost)
                $('input[name="delivery-service"]').val(deliveryService)
                $('#finish-form').submit()
              }
            });
          },
          error: function(response) {
            console.log(response)
          },
        });

      })
    })
</script>

<script>
  $('select[name="delivery"]').on('change', function() {
      let deliveryValues = $(this).val().split('__')
      let deliveryCost = deliveryValues[0]
      let deliveryService = deliveryValues[1]

      if ($('#delivery-cost')) {
        $('#delivery-cost').remove()
      }

      $('#checkout-detail').append(
        `<p class="d-flex" id="delivery-cost">
          <span>Delivery</span>
          <span>${deliveryCost}</span>
        </p>`
      )

      $('input[name="delivery-cost"]').val(deliveryCost)
      $('input[name="delivery-service"]').val(`JNE ${deliveryService}`)
      let subtotal = parseInt($('span.total').text())
      let delivery = parseInt(deliveryCost)
      $('span.total').text(`${subtotal + delivery}`)
    })
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Grandonk\sertifikasi_grandonk\sehat-sentosa\resources\views/checkout.blade.php ENDPATH**/ ?>