

<?php $__env->startSection('content'); ?>

<div class="container-fluid p-0">

  <h1 class="display-6 mb-3"><?php echo e($title); ?></h1>

  <div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-body">

          <form action="<?php echo e(route('admin.category.update', $category)); ?>" method="post" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>

            <div class="form-group row mb-3">
              <label for="name" class="col-form-label col-sm-2">Name</label>
              <div class="col-sm-10">
                <input type="text" class="slug-from form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name"
                  name="name" value="<?php echo e(old('name', $category->name)); ?>">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                  <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>

            <div class="form-group row mb-3">
              <label for="slug" class="col-form-label col-sm-2">Slug</label>
              <div class="col-sm-10">
                <input type="text" readonly class="slug-field form-control <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                  id="slug" name="slug" value="<?php echo e(old('slug', $category->slug)); ?>">
                <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                  <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>

            <div class="form-group row mb-3">
              <?php if($category->image): ?>
              <div class="img-container d-flex justify-content-end">
                <img height="120" width="120" src="<?php echo e(asset('storage/' . $category->image)); ?>"
                  class="img-preview mb-2 border border-dark" style="object-fit: cover;">
              </div>
              <?php else: ?>
              <div class="d-none img-container justify-content-end">
                <img height="120" width="120" class="img-preview mb-2 border border-dark" style="object-fit: cover;">
              </div>
              <?php endif; ?>

              <label for="image" class="col-form-label col-sm-2">Image</label>
              <input type="hidden" name="oldImage" value="<?php echo e($category->image); ?>">

              <div class="col-sm-10">
                <input onchange="previewImg();" name="image"
                  class="img-input form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file">
                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                  <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>

            <div class="d-flex justify-content-end">
              <button type="submit" class="btn btn-primary mr-2">
                Submit
              </button>
              <a class="btn btn-warning" href="<?php echo e(route('admin.category.index')); ?>">
                Cancel
              </a>
            </div>

          </form>

        </div>
      </div>
      <form action="<?php echo e(route('admin.category.destroy', $category)); ?>" method="POST">
        <?php echo method_field('DELETE'); ?>
        <?php echo csrf_field(); ?>

        <button onclick="return confirm('Are You Sure ?')" type="submit"
          class="btn btn-lg btn-danger rounded mb-3">Delete
          Category</button>
      </form>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('admin-asset/js/imagePreview.js')); ?>"></script>
<script src="<?php echo e(asset('admin-asset/js/generateSlug.js')); ?>"></script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Grandonk\sertifikasi_grandonk\sehat-sentosa\resources\views/admin/category/edit.blade.php ENDPATH**/ ?>